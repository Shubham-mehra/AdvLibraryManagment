﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdvLibraryManagment.Controllers
{
    public class AdminBookDataController : Controller
    {
        // GET: AdminBookData
        public ActionResult Index()
        {
            return View();
        }
    }
}