﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdvLibraryManagment.Models;
using AdvLibraryManagment.Models.ViewModel;

namespace AdvLibraryManagment.Controllers
{

    public class AdminController : Controller
    {
        LibraryManagmentEntities1 _connection = new LibraryManagmentEntities1();
        // GET: Admin
        
       
        public ActionResult Index()
        {
            
            return View();
        }
        [HttpPost]
        public ActionResult AdminLogIn(BindingOfTables values)
        {
            AdminLogInDetail AdminDetail = _connection.AdminLogInDetail.Where(s => s.AdminId == values.AdminId && s.AdminPassword == values.AdminPassword).FirstOrDefault();

            if (AdminDetail != null)
            {
                return RedirectToAction("Index", "Home");

            }
            else
            {
                TempData["LoginErrorMsg"] = "* User Name and password not match Please check and try Again Later";
                return RedirectToAction("Index", "Admin");
            }
        }
    }
}