﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdvLibraryManagment.Models;
using AdvLibraryManagment.Models.ViewModel;

namespace AdvLibraryManagment.Controllers
{
    public class BooksController : Controller
    {
        // GET: Books
        LibraryManagmentEntities1 _Connection = new LibraryManagmentEntities1();
        public ActionResult Index()
        {

            var BookData = new List<BookDetail>();
            var BooksIdsData = new List<SelectListItem>();


            var BooksId = _Connection.BookDetail.ToList();//connection for the books id
            //var StudentId = _Connection.StudentDetail.ToList();//Connecton for the Student Ids
            
            
            //----------------------------loop for the student Ids ---------------------//

            //foreach (var i in StudentId)
            //{
            //    StudentIdsData.Add(new SelectListItem()
            //    {

            //        Value = i.Id.ToString(),
            //        Text = i.Id
            //    });
            //}

            //----------------------------loop for the Books Ids ---------------------//

            foreach (var i in BooksId)
            {
                BooksIdsData.Add(new SelectListItem()
                {

                    Value = i.BookId.ToString(),
                    Text = i.BookId.ToString()
                });
            }


            BookData = _Connection.BookDetail.ToList();

            var SelectBookList = new BindingOfTables()
            {
                BookList = BookData,
                BooksIdsList=BooksIdsData
            };
          
            return View(SelectBookList);

        }
        [HttpPost]
        public ActionResult IssueBook(BindingOfTables values)
        {

            _Connection.BookTransection.Add(new BookTransection() { BookId = values.BookTransectionDetail.BookId, BookName=values.BookTransectionDetail.BookName,StudentBranch=values.BookTransectionDetail.StudentBranch,StudentIds=values.BookTransectionDetail.StudentIds,StudentYear=values.BookTransectionDetail.StudentYear,StudentName=values.BookTransectionDetail.StudentName});
            _Connection.SaveChanges();


            //BookDetail BD = _Connection.BookDetail.Where(s => s.BookId.ToString() == values.BookTransectionDetail.BookId).FirstOrDefault();
            //BD.StudentIds = values.BookTransectionDetail.StudentIds;
            //_Connection.SaveChanges();



            return RedirectToAction("Index","Books");
        }





     //***************************************Json for the binding of the book name and book ID in issue /result Book********************
        [HttpGet]
        public JsonResult GetbooknamefromdropdwonId(String BookDropdownId,BindingOfTables values)
        {
            var IdBook = _Connection.BookDetail.Where(s => s.BookId.ToString() == BookDropdownId).ToList();
            var Id_Book = new List<SelectListItem>();
           
           
            foreach (var item in IdBook)
            {
                Id_Book.Add(new SelectListItem()
                {
                    Text = item.BookTitle
                    ,
                    Value = item.BookId.ToString()

                });
            }
            return Json(Id_Book, JsonRequestBehavior.AllowGet);
        }

        

[HttpGet]
        public JsonResult GetbooknamefromdropdwonIdreturn(String BookDropdownIdreturn,BindingOfTables values)
        {
            var IdBook = _Connection.BookDetail.Where(s => s.BookId.ToString() == BookDropdownIdreturn).ToList();
            var Id_Book = new List<SelectListItem>();
            TempData["Student"] = values.StudentId;
            foreach (var item in IdBook)
            {
                Id_Book.Add(new SelectListItem()
                {
                    Text = item.BookTitle
                    ,
                    Value = item.BookId.ToString()

                });
            }
            return Json(Id_Book, JsonRequestBehavior.AllowGet);
        }

        //public ActionResult ViewAllBooks()
        //{




        //}

    }
}