﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdvLibraryManagment.Models;
using AdvLibraryManagment.Models.ViewModel;
namespace AdvLibraryManagment.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
       
        LibraryManagmentEntities1 _connection = new LibraryManagmentEntities1();
        
        public ActionResult Index()
        {
            var BookData = new List<BookDetail>();


            BookData = _connection.BookDetail.ToList();
            var SelectBookList = new BindingOfTables()
            {
                BookList = BookData
            };
            return View(SelectBookList);
        }
        [HttpPost]
        public ActionResult Index(String Name, String Author, String ISBN)
        {
            var BookData = new List<BookDetail>();


            
        
                if (!String.IsNullOrEmpty(Name) && String.IsNullOrEmpty(Author))
                    {
                    BookData = _connection.BookDetail.Where(m => m.BookTitle.Contains(Name)).ToList();
                    }
                 else if (!String.IsNullOrEmpty(Name) && !String.IsNullOrEmpty(Author))
                    {
                        BookData = _connection.BookDetail.Where(m => m.Author.Contains(Author)&&m.BookTitle.Contains(Name)).ToList();
                    }
                else if (!String.IsNullOrEmpty(Author) && String.IsNullOrEmpty(Name))
                    {
                        BookData = _connection.BookDetail.Where(m => m.Author.Contains(Author)).ToList();
                    }
                else
                    {
                        TempData["Error Msg"] = "*No Book Present Accoding To Given Info By You";
                        BookData = _connection.BookDetail.ToList();
                    }
            var SelectBookList = new BindingOfTables()
            {
                BookList = BookData
            };
            return View(SelectBookList);
        }
    }
}