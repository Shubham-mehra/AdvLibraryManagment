﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdvLibraryManagment.Models;
using AdvLibraryManagment.Models.ViewModel;

namespace AdvLibraryManagment.Controllers
{
    public class IssueReturnController : Controller
    {
        LibraryManagmentEntities1 _Connection = new LibraryManagmentEntities1();


        // GET: IssueReturn
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult StudentLogin( BindingOfTables values)
        {
            StudentDetail StudentLoginObject = _Connection.StudentDetail.Where(s=>s.Id==values.StudentId &&s.LibPassword==values.StudentPassword).FirstOrDefault();
            if (StudentLoginObject != null)
            {
                TempData["Student"] = values.StudentId;
                return RedirectToAction("Index", "Books");

            }
            else
            {
                TempData["LoginErrorMsgStudent"] = "*User Name and password not match Please check and try Again Later";
                return RedirectToAction("Index", "IssueReturn");
            }
        }
        public ActionResult TeacherLogin(BindingOfTables values)
        {
            TeachersDetail StudentLoginObject = _Connection.TeachersDetail.Where(s => s.Id == values.TeacherId&& s.LibPassword==values.TeacherPassoword).FirstOrDefault();
            if (StudentLoginObject != null)
            {
                return RedirectToAction("Index", "StudentPannel");

            }
            else
            {
                TempData["LoginErrorMsgTeacher"] = "*User Name and password not match Please check and try Again Later";
                return RedirectToAction("Index", "IssueReturn");
            }
        }
    }
}