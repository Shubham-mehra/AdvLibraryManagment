﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdvLibraryManagment.Controllers
{
    public class StudentPannelController : Controller
    {
        // GET: StudentPannel
        public ActionResult Index()
        {
            return View();
        }
    }
}