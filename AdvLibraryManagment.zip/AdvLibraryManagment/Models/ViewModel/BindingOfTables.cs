﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdvLibraryManagment.Models;

namespace AdvLibraryManagment.Models.ViewModel
{
    public class BindingOfTables
    {
        public StudentDetail stdDetail { get; set; }
        public String StudentId { get; set; }
        public String StudentPassword { get; set; }
        public String TeacherId { get; set; }
        public String TeacherPassoword { get; set; }
        public List<BookDetail> BookList { get; set; }
        public String AdminId { get; set; }
        public String AdminPassword { get; set; }
        public BookTransection BookTransectionDetail { get; set; }
        public BookDetail BookIdFromBookDetail { get; set; }
        public List<SelectListItem> StudentsIdsList { get; set; }
        public List<SelectListItem> BooksIdsList { get; set; }
        public String StudentIds { get; set; }
        public String BookDropdownId { get; set; }
        public String BookDropdownIdreturn { get; set; }
        public String StudentuserName { get; set; }
        

        
    }
}